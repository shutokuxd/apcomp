
public class methods 
{
    public static void main(String[] args) 
    {
        int rNum = 10;  //getRandomNum();
        int rNum2 = 5;  //getRandomNum();
//        int sum = add(rNum, rNum2);
//        System.out.println(sum);
//        
//        System.out.println(rNum);
//        sayHello();
//        sayHello();
    if(isOdd(4)==true) System.out.println("Odd");
    }
    public static boolean isOdd(int num)
    {
        if(num%2 ==1)return true;
        else return false;
    }
//    public static int add (int a, int b)
//    {
//      a++;
//      b++;
//      int sum = a + b;
//      return sum;
//    }
//     public static int getRandomNum()
//    {
//        int r = (int)(Math.random()*100)+1;
//        return r;
//    }
//    public static void sayHello () 
//    {
//        System.out.println("Hello");
//    }
}
